package br.com.auladeaprendizado.odonto;

public class Pagamentos {

}
