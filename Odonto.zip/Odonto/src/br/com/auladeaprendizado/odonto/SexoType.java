package br.com.auladeaprendizado.odonto;

public enum SexoType {
 M,F;
	
	
 
}
